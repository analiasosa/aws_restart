input ("Colocar una frase")
input ("Colocar una letra")
while 
print (x)
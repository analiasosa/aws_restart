input ("Colocar una frase")
input ("Colocar una letra")
for x in range (a, z)
print (x)
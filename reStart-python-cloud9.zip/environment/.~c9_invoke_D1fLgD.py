frase = input ("Colocar una frase")
letra = input ("Colocar una letra")
for letra in 
    print (x)
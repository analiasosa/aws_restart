input ("Colocar una frase")
input ("Colocar una letra")
for 
print (x)
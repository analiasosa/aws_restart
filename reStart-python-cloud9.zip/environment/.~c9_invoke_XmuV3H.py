input ("Colocar una frase")
input ("Colocar una letra")
for x in ra
print (x)
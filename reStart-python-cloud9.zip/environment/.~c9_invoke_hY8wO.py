input ("Colocar una frase")
input ("Colocar una letra")
"""
print (x)
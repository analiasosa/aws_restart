print ("Count to 10!")
for x in range (0, 11): # x es una variable, range cuenta del 0 al 10(se le agrega uno mas)
          print(x) # imprime todo hasta salir del bucle, que es llegar a 10